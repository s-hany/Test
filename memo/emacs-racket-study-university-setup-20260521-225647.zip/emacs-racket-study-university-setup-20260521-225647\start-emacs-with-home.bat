@echo off
set "HOME=%USERPROFILE%"
start "" emacs.exe
