;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260405.1815"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "7d234fd65f835b0e5608404000cef12b2c9f97b3"
  :revdesc "7d234fd65f83"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
