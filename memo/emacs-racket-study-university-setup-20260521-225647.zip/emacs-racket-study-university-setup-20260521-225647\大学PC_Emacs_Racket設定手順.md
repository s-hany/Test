# 大学PCへの Emacs + Racket 学習用設定 導入手順

このZIPには、Racket学習向けEmacs設定を別PCへ移すための最小一式が入っています。

## 入っているもの

```text
.emacs.d/
  init.el
  racket-study-completions.el
  elpa/
start-emacs-with-home.bat
```

- `init.el`: Emacs本体の設定
- `racket-study-completions.el`: Racket組み込み関数、数学/SICP補助、学習用例の補完辞書
- `elpa/`: `company`, `racket-mode`, `smartparens` などのEmacsパッケージ
- `start-emacs-with-home.bat`: `HOME` を一時的に指定してEmacsを起動する補助bat

元のMarkdown資料は実行時には不要です。補完辞書は `racket-study-completions.el` に静的に入っています。

## 事前確認

大学PCで以下を確認してください。

1. 大学の利用規約上、ユーザーフォルダ内に設定ファイルを置いてよいこと。
2. Emacs が使えること。
3. Racket が使えること。

PowerShell またはコマンドプロンプトで確認します。

```powershell
emacs --version
racket --version
```

`racket --version` が動かない場合は、Racketが未インストールか、PATHが通っていません。大学PCにRacketが入っていてもPATHにない場合は、`init.el` の次の行を実際の場所に合わせます。

```elisp
(racket-program "racket.exe")
```

例:

```elisp
(racket-program "C:/Program Files/Racket/Racket.exe")
```

## 導入手順

1. ZIPを展開します。
2. 大学PCのユーザーフォルダを確認します。

```powershell
echo $env:USERPROFILE
```

通常は次のような場所です。

```text
C:\Users\<大学PCのユーザー名>
```

3. 既存の `.emacs.d` がある場合は、必ず退避します。

```powershell
Rename-Item "$env:USERPROFILE\.emacs.d" ".emacs.d.backup"
```

4. ZIP内の `.emacs.d` フォルダを、大学PCのユーザーフォルダ直下へコピーします。

コピー後の形:

```text
C:\Users\<大学PCのユーザー名>\.emacs.d\init.el
C:\Users\<大学PCのユーザー名>\.emacs.d\racket-study-completions.el
C:\Users\<大学PCのユーザー名>\.emacs.d\elpa\
```

## HOMEの設定

Emacsが `~\.emacs.d\init.el` を読むために、`HOME` がユーザーフォルダを指している必要があります。

可能なら、ユーザー環境変数に設定します。

```powershell
[Environment]::SetEnvironmentVariable("HOME", $env:USERPROFILE, "User")
```

設定後、Emacsやターミナルを開き直してください。

大学PCで環境変数を変更できない場合は、同梱の `start-emacs-with-home.bat` からEmacsを起動してください。

## 動作確認

Emacsを起動して、`.rkt` ファイルを開きます。

新しい空の `.rkt` ファイルなら、先頭に次が自動挿入されます。

```racket
#lang racket
```

確認する補完例:

- `map`: `[builtin]` として出る。選ぶと `map` が入る。
- `sqrt`: `[builtin]` として出る。
- `square`: 未定義なら `[math define]` として出る。選ぶと `(define (square x) (* x x))` が入る。
- 同じファイル内に `(define (square x) (* x x))` がある場合、`square` は `[math call]` として出る。選ぶと `square` だけ入る。

Racket用キー:

```text
C-c r r  実行
C-c r R  実行してREPLへ移動
C-c r t  テスト
C-c r e  定義をREPLへ送信
C-c r x  直前の式をREPLへ送信
C-c r d  説明
C-c r h  ドキュメント検索
C-c r n  次のエラー
C-c r p  前のエラー
```

## 注意点

- 大学PCはログアウト時にユーザーフォルダが初期化される場合があります。
- ネットワーク制限がある環境では、Emacsパッケージの再取得に失敗することがあります。このZIPの `elpa/` を一緒にコピーするのが安全です。
- macOS/Linuxへ移す場合は、`racket-program` を `"racket"` に変更してください。
- 既存のEmacs設定があるPCでは、必ずバックアップしてから置き換えてください。

## 戻し方

この設定を外したい場合は、コピーした `.emacs.d` を削除またはリネームし、退避していた `.emacs.d.backup` を戻します。

```powershell
Rename-Item "$env:USERPROFILE\.emacs.d" ".emacs.d.racket-study"
Rename-Item "$env:USERPROFILE\.emacs.d.backup" ".emacs.d"
```

