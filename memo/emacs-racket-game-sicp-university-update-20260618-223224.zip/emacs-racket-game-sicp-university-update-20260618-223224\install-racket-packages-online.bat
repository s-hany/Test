@echo off
where raco >nul 2>nul
if errorlevel 1 (
  echo raco.exe was not found. Install Racket 9.1 first.
  pause
  exit /b 1
)
raco pkg install --user --auto --batch --skip-installed sicp reactor
if errorlevel 1 (
  echo Package installation failed.
  pause
  exit /b 1
)
echo SICP and Reactor packages are ready.
pause