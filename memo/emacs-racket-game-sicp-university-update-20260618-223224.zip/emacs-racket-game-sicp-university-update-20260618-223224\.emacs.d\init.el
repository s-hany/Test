;;; init.el --- Emacs configuration -*- lexical-binding: t -*-
;;; Commentary:
;;; Code:

(when (eq system-type 'darwin)
  (setq mac-command-modifier 'meta))

(prefer-coding-system 'utf-8)

(setq x-select-enable-clipboard t
      x-select-enable-primary t
      save-interprogram-paste-before-kill t
      apropos-do-all t
      mouse-yank-at-point t)

;; 警告音と画面フラッシュが鬱陶しいため無効化
(setq ring-bell-function 'ignore)

;; Emacsチュートリアル
(keymap-set global-map "C-h t" #'help-with-tutorial-spec-language)
;; 操作に慣れてきたら，以下の2行のコメントアウトを外すのがおすすめ
;; （C-hは直前の1文字の削除．ヘルプはM-hで開く．）
;; (keymap-global-set "C-h" #'delete-backward-char)
;; (keymap-global-set "M-h" #'help)

;; コマンド履歴を保存
(savehist-mode 1)
;; ファイル内のカーソル位置を記憶
(save-place-mode 1)

;; インデントにタブ文字を使わない
(setq-default indent-tabs-mode nil)

;; オープン中のバッファが他所で変更された際の同期処理
(global-auto-revert-mode 1)
;; Dired等も自動更新
(setq global-auto-revert-non-file-buffers t)

;; Emacs中のファイル削除は「ごみ箱へ移動」
(setq delete-by-moving-to-trash t)

;; フレームやウィンドウのリサイズをスムーズに
(setq window-resize-pixelwise t)
(setq frame-resize-pixelwise t)

;; スクロールもスムーズに
(pixel-scroll-precision-mode 1)

;; マウソポインタの位置に追随して自動でウィンドウをセレクト
(setq mouse-autoselect-window t)

;; マウスのドラッグ＆ドロップでリージョンのコピペを可能に
;; Emacs以外へもコピペ可能にする
(setq mouse-drag-and-drop-region-cross-program t)
;; Metaキーを押しながらドロップ = 同一バッファ内でも移動ではなくコピー
(setq mouse-drag-and-drop-region 'meta)

;; グローバルなフォントスケーリングにフレームサイズを追随
(setq global-text-scale-adjust-resizes-frames t)

;; ツールバー不要
(tool-bar-mode -1)
;; メニューバー不要
(menu-bar-mode -1)

;; ウィンドウの縁を掴めるようにする
(window-divider-mode)
(setq-default window-divider-default-right-width 1)

;; 初期フレームサイズ
(add-to-list 'default-frame-alist '(width . 83))
(add-to-list 'default-frame-alist '(height . 36))
;; 80文字目に罫線
;; (setq-default display-fill-column-indicator-column 80)
;; (global-display-fill-column-indicator-mode)

;; カーソルの見た目
(setq-default cursor-type '(bar . 3))
(blink-cursor-mode -1)

;; ウィンドウの横幅を超える行を自動で折り返す
(setq-default truncate-lines nil)

;; シンタックス・ハイライト
(setq font-lock-maximum-decoration t)

;; 括弧の対応を強調表示
(show-paren-mode t)

;; 現在行をハイライト表示
;; (global-hl-line-mode t)

;; モードラインにカラムを表示
(column-number-mode t)

;; delete selection modeを有効化
(delete-selection-mode)

;; minibufferのdefaultをスマート化
(minibuffer-electric-default-mode)

;; Ctrl+マウスホイール（トラックパッド含む）による
;; text-scale-adjustの誤爆を防止
(global-unset-key (kbd "C-<wheel-up>"))
(global-unset-key (kbd "C-<wheel-down>"))
(global-unset-key (kbd "C-<mouse-4>"))
(global-unset-key (kbd "C-<mouse-5>"))


;; External packages

(use-package package
  :config
  (add-to-list 'package-archives
               '("melpa" . "https://melpa.org/packages/"))
  ;; (package-initialize)
  )

(setopt use-package-always-ensure t)
(setopt package-native-compile nil)
;; (setopt warning-minimum-level :emergency)

(use-package use-package
  :ensure nil)

;; PC room only
;; (unless (package-installed-p 'compat)
;;   (package-install-file "~/.emacs.d/compat-30.1.0.1.0.20260131.205608.tar"))
;; (use-package compat
;;   :ensure nil)

;; org-modern
(use-package org-modern
  :after org
  :hook
  ((org-mode . org-indent-mode)
   (org-mode . org-modern-mode)
   (org-agenda-finalize-hook . org-modern-agenda))
  :config
  (defun my/org-indent-redraw ()
    "Force redraw of org-indent overlays."
    (interactive)
    (org-indent-mode -1)
    (org-indent-mode 1))
  :bind
  (:map org-mode-map
        ("C-c i" . my/org-indent-redraw)))

;; Display page-break (\f, C-q C-l) as a horizontal line
(use-package page-break-lines
  :config
  (add-to-list 'page-break-lines-modes 'racket-mode)
  (custom-set-faces
   '(page-break-lines ((t (:foreground "gray30" :family "Courier" :height 1)))))
  (setq page-break-lines-max-width (if (eq system-type 'windows-nt) 40 68))
  (global-page-break-lines-mode 1))

;; Smart minibuffer
(use-package vertico
  :init
  (vertico-mode)
  :custom
  (vertico-sort-function 'vertico-sort-history-alpha))
;; Search for partial matches in any order
(use-package orderless
  :custom
  (completion-styles '(orderless basic))
  (completion-category-defaults nil)
  (completion-category-overrides
   '((file (styles partial-completion)))))
;; Enable richer annotations using the Marginalia package
(use-package marginalia
  :init
  (marginalia-mode))
;; Improve keyboard shortcut discoverability
(use-package which-key
  :config
  (which-key-mode)
  :custom
  (which-key-max-description-length 40)
  (which-key-lighter nil)
  (which-key-sort-order 'which-key-description-order))

;; Auto-comletion for all mode
(use-package company
  :demand t
  :custom
  (company-idle-delay 0.05)
  (company-minimum-prefix-length 1)
  (company-tooltip-align-annotations t)
  (company-selection-wrap-around t)
  :bind
  ("M-/" . company-complete)
  (:map company-active-map
        ("C-n" . company-select-next)
        ("C-p" . company-select-previous)
        ("<tab>" . company-complete-selection)
        ("C-d" . company-show-doc-buffer)
        ("M-." . company-show-location))
  :config
  (global-company-mode 1))

;; Tiny documentation in echo area
(use-package eldoc-mouse
  :custom
  (eldoc-mouse-posframe-max-width 80)
  (eldoc-mouse-posframe-max-height 16)
  ;; (eldoc-mouse-idle-time 1.2) ;; default = 0.4
  :hook eldoc-mode)

;; Appearance
(use-package modus-themes
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts t)
  (modus-themes-to-toggle '(modus-operandi-tinted
			    modus-vivendi-tinted))
  :bind
  (("C-c t t" . modus-themes-toggle)
   ("C-c t m" . modus-themes-select)))
;(use-package ef-themes)
(use-package doom-themes)
(load-theme 'modus-vivendi-tinted t) ; change here

;; Paren editing
(use-package smartparens
  :config
  (require 'smartparens-config)
  (smartparens-global-mode t)
  (setq sp-highlight-pair-overlay nil
        sp-highlight-wrap-overlay nil
        sp-highlight-wrap-tag nil
        sp-autowrap-region t)
  (defun my/sp-wrap-region-or-insert (pair)
    "Wrap the active region with PAIR, or insert PAIR normally."
    (if (use-region-p)
        (sp-wrap-with-pair pair)
      (let ((close (pcase pair
                     ("(" ")")
                     ("[" "]")
                     (_ ""))))
        (insert pair close)
        (backward-char (length close)))))
  (defun my/sp-wrap-or-insert-paren ()
    "Wrap active region with parentheses, or insert a pair."
    (interactive "*")
    (my/sp-wrap-region-or-insert "("))
  (defun my/sp-wrap-or-insert-bracket ()
    "Wrap active region with brackets, or insert a pair."
    (interactive "*")
    (my/sp-wrap-region-or-insert "["))
  (keymap-set prog-mode-map "(" #'my/sp-wrap-or-insert-paren)
  (keymap-set prog-mode-map "[" #'my/sp-wrap-or-insert-bracket)
  :hook ((prog-mode . smartparens-mode) ;; smartparens-strict-mode
         (eval-expression-minibuffer-setup . smartparens-mode))
  :bind (:map sp-keymap
              ;; ("M-s" . nil)
              ("M-]" . sp-forward-slurp-sexp)
              ("M-[" . sp-forward-barf-sexp)))

;; Racket mode
(load (locate-user-emacs-file "racket-study-completions.el") t)
(require 'tempo)

(defvar my/racket-format-on-save t
  "When non-nil, indent Racket buffers before saving.")

(defvar my/racket-tempo-tags nil
  "Tempo snippets for Racket study buffers.")

(defconst my/racket-snippet-catalog
  '((:trigger "def"
     :category "definition"
     :description "関数定義"
     :inserts "(define (name args)\n  body)")
    (:trigger "lam"
     :category "function call"
     :description "無名関数"
     :inserts "(lambda (args)\n  body)")
    (:trigger "let"
     :category "local binding"
     :description "局所束縛"
     :inserts "(let ([name value])\n  body)")
    (:trigger "cond"
     :category "conditional"
     :description "条件分岐"
     :inserts "(cond\n  [test result]\n  [else value])")
    (:trigger "check"
     :category "test"
     :description "check-expect テスト"
     :inserts "(check-expect actual expected)")
    (:trigger "ceq"
     :category "test"
     :description "rackunit の check-equal?"
     :inserts "(check-equal? actual expected)")
    (:trigger "rack"
     :category "test"
     :description "rackunit を読み込む"
     :inserts "(require rackunit)")
    (:trigger "lrec"
     :category "ex14: list recursion"
     :description "ex14前半のリスト再帰の型"
     :inserts "(define (f items)\n  (if (null? items)\n      '()\n      (cons (process (car items))\n            (f (cdr items)))))")
    (:trigger "lsel"
     :category "ex14: list recursion"
     :description "条件に合う要素だけ残す型"
     :inserts "(define (select items)\n  (cond ((null? items) '())\n        ((keep? (car items))\n         (cons (car items)\n               (select (cdr items))))\n        (else\n         (select (cdr items)))))")
    (:trigger "trec"
     :category "ex14: tree recursion"
     :description "空・葉・枝の3分岐tree再帰"
     :inserts "(define (walk tree)\n  (cond ((null? tree) '())\n        ((not (pair? tree)) tree)\n        (else\n         (combine (walk (car tree))\n                  (walk (cdr tree))))))")
    (:trigger "leaf"
     :category "ex14: tree recursion"
     :description "葉を集めるfringe型"
     :inserts "(define (fringe-like tree)\n  (cond ((null? tree) '())\n        ((not (pair? tree)) (list tree))\n        (else\n         (append (fringe-like (car tree))\n                 (fringe-like (cdr tree))))))")
    (:trigger "foreach"
     :category "ex14: side effect"
     :description "副作用を順に実行する型"
     :inserts "(define (for-each-like proc items)\n  (if (null? items)\n      'done\n      (begin\n        (proc (car items))\n        (for-each-like proc (cdr items)))))")
    (:trigger "varargs"
     :category "ex14: variable arguments"
     :description "可変長引数を選択する型"
     :inserts "(define (same-kind first . rest)\n  (define (same? x)\n    (same-rule? x first))\n  (define (select items)\n    (cond ((null? items) '())\n          ((same? (car items))\n           (cons (car items)\n                 (select (cdr items))))\n          (else\n           (select (cdr items)))))\n  (cons first\n        (select rest)))")
    (:trigger "mpdisp"
     :category "review: message passing"
     :description "dispatch を返すメッセージパッシング型"
     :inserts "(define (make-object a b)\n  (define (dispatch op)\n    (cond ((eq? op 'message-a) a)\n          ((eq? op 'message-b) b)\n          (else\n           (error \"Unknown op\" op))))\n  dispatch)")
    (:trigger "derivpow"
     :category "review: symbolic derivation"
     :description "べき乗の微分分岐"
     :inserts "((exponentiation? exp)\n (make-product\n  (make-product\n   (exponent exp)\n   (make-exponentiation\n    (base exp)\n    (make-sum (exponent exp) -1)))\n  (deriv (base exp) var)))")
    (:trigger "nary"
     :category "review: symbolic derivation"
     :description "3項以上の和・積の残りを演算式へ戻す型"
     :inserts "(define (rest-operand exp op)\n  (let ((rest (cddr exp)))\n    (if (null? (cdr rest))\n        (car rest)\n        (cons op rest))))")
    (:trigger "oset"
     :category "review: ordered set"
     :description "整列集合を先頭比較でマージする型"
     :inserts "(define (union-set set1 set2)\n  (cond ((null? set1) set2)\n        ((null? set2) set1)\n        (else\n         (let ((x1 (car set1))\n               (x2 (car set2)))\n           (cond ((= x1 x2)\n                  (cons x1 (union-set (cdr set1) (cdr set2))))\n                 ((< x1 x2)\n                  (cons x1 (union-set (cdr set1) set2)))\n                 (else\n                  (cons x2 (union-set set1 (cdr set2)))))))))")
    (:trigger "huff"
     :category "review: huffman"
     :description "ハフマン木で記号をビット列へ変換する型"
     :inserts "(define (encode-symbol sym tree)\n  (cond ((leaf? tree) '())\n        ((memq sym (symbols (left-branch tree)))\n         (cons 0 (encode-symbol sym (left-branch tree))))\n        ((memq sym (symbols (right-branch tree)))\n         (cons 1 (encode-symbol sym (right-branch tree))))\n        (else\n         (error \"symbol not in tree\" sym))))")
    (:trigger "smerge"
     :category "review: huffman"
     :description "先頭2つを合体して1本のハフマン木にする型"
     :inserts "(define (successive-merge ordered-trees)\n  (cond ((null? ordered-trees) '())\n        ((null? (cdr ordered-trees)) (car ordered-trees))\n        (else\n         (successive-merge\n          (adjoin-set\n           (make-code-tree (car ordered-trees)\n                           (cadr ordered-trees))\n           (cddr ordered-trees))))))")
    (:trigger "applygen"
     :category "review: generic arithmetic"
     :description "型タグから表を引く apply-generic 型"
     :inserts "(define (apply-generic op . args)\n  (let ((type-tags (map type-tag args)))\n    (let ((proc (get op type-tags)))\n      (if proc\n          (apply proc (map contents args))\n          (error \"No method for these types: APPLY-GENERIC\"\n                 (list op type-tags))))))")
    (:trigger "tagged"
     :category "review: generic arithmetic"
     :description "scheme-number を裸の数値として扱う型タグ一式"
     :inserts "(define (attach-tag type-tag contents)\n  (if (and (eq? type-tag 'scheme-number)\n           (number? contents))\n      contents\n      (cons type-tag contents)))\n\n(define (type-tag datum)\n  (cond ((number? datum) 'scheme-number)\n        ((pair? datum) (car datum))\n        (else (error \"Bad tagged datum: TYPE-TAG\" datum))))\n\n(define (contents datum)\n  (cond ((number? datum) datum)\n        ((pair? datum) (cdr datum))\n        (else (error \"Bad tagged datum: CONTENTS\" datum))))")
    (:trigger "gbang"
     :category "game: loop"
     :description "2htdp/universeのゲームループ"
     :inserts "(require 2htdp/image)\n(require 2htdp/universe)\n\n(define (draw-scene w)\n  (empty-scene 400 400 \"white\"))\n(define (next w) w)\n(define (control w key) w)\n\n(big-bang initial-world\n  (to-draw draw-scene)\n  (on-tick next)\n  (on-key control))")
    (:trigger "gworld"
     :category "game: world"
     :description "world生成関数とセレクタ"
     :inserts "(define (world player-x player-y score)\n  (list player-x player-y score))\n\n(define (world-player-x w) (car w))\n(define (world-player-y w) (cadr w))\n(define (world-score w) (caddr w))")
    (:trigger "gdraw"
     :category "game: drawing"
     :description "worldから画面を描く関数"
     :inserts "(define (draw-scene w)\n  (place-image PLAYER\n               (world-player-x w)\n               (world-player-y w)\n               SCENE))")
    (:trigger "gkey"
     :category "game: input"
     :description "左右移動とスペースキーの入力処理"
     :inserts "(define (control w key)\n  (cond ((key=? key \"left\") (move-left w))\n        ((key=? key \"right\") (move-right w))\n        ((key=? key \" \") (fire w))\n        (else w)))")
    (:trigger "gtick"
     :category "game: update"
     :description "毎tickのworld更新"
     :inserts "(define (next w)\n  (world (move-player (world-player w))\n         (move-enemies (world-enemies w))\n         (move-shots (world-shots w))))")
    (:trigger "gmouse"
     :category "game: input"
     :description "クリック座標から盤面を更新"
     :inserts "(define (control-mouse w x y kind)\n  (if (mouse=? kind \"button-down\")\n      (let ((row (quotient y CELL-SIZE))\n            (col (quotient x CELL-SIZE)))\n        (if (inside-board? row col)\n            (update-at-click w row col)\n            w))\n      w))")
    (:trigger "ghit"
     :category "game: collision"
     :description "中心座標を使う矩形当たり判定"
     :inserts "(define (rect-hit? x1 y1 width1 height1 x2 y2 width2 height2)\n  (and (< (abs (- x1 x2)) (/ (+ width1 width2) 2))\n       (< (abs (- y1 y2)) (/ (+ height1 height2) 2))))")
    (:trigger "ggrid"
     :category "game: board"
     :description "二次元リスト盤面の参照と更新"
     :inserts "(define (board-ref board row col)\n  (list-ref (list-ref board row) col))\n\n(define (board-update board row col value)\n  (list-set board row\n            (list-set (list-ref board row) col value)))")
    (:trigger "rsig"
     :category "reactor: signal"
     :description "signalの待機と発生"
     :inserts "(define-signal event #f)\n\n(define (receiver)\n  (await& event\n          (value (displayln value))))\n\n(exec-run\n (par& (receiver)\n       (begin pause&\n              (emit& event \"ready\"))))")
    (:trigger "rpar"
     :category "reactor: parallel"
     :description "複数のリアクティブ処理を並行実行"
     :inserts "(exec-run\n (par& (producer)\n       (consumer)\n       (controller)))")
    (:trigger "rpipe"
     :category "reactor: stream"
     :description "enumerate/filter/map/accumulateのsignalパイプライン"
     :inserts "(exec-run\n (par& (print-results result)\n       (signal-accumulate result + 0 mapped)\n       (signal-map mapped square filtered)\n       (signal-filter filtered odd? source)\n       (enumerate-interval source 1 20)))")
    (:trigger "sstream"
     :category "sicp: stream"
     :description "SICPのstreamを再帰的に作る"
     :inserts "(define (stream-from n)\n  (cons-stream n\n               (stream-from (+ n 1))))")
    (:trigger "sdelay"
     :category "sicp: delayed"
     :description "delayした式をforceする"
     :inserts "(define delayed-value\n  (delay expression))\n\n(force delayed-value)")
    (:trigger "smut"
     :category "sicp: mutation"
     :description "set!で状態を持つクロージャ"
     :inserts "(define counter\n  (let ((value 0))\n    (lambda ()\n      (set! value (+ value 1))\n      value)))")
    (:trigger "statelet"
     :category "ex20: state closure"
     :description "letで状態を閉じ込めるクロージャ"
     :inserts "(define object\n  (let ((state initial-value))\n    (lambda (x)\n      (set! state (update state x))\n      state)))")
    (:trigger "msgdisp"
     :category "ex20: account"
     :description "メッセージで処理を選ぶdispatch"
     :inserts "(define (dispatch m)\n  (cond ((eq? m 'message-a) procedure-a)\n        ((eq? m 'message-b) procedure-b)\n        (else\n         (error \"Unknown request\" m))))")
    (:trigger "passacc"
     :category "ex20: account"
     :description "パスワードつき口座dispatch"
     :inserts "(define (dispatch given-pass m)\n  (if (eq? given-pass pass)\n      (cond ((eq? m 'withdraw) withdraw)\n            ((eq? m 'deposit) deposit)\n            (else (error \"Unknown request\" m)))\n      incorrect))")
    (:trigger "badpass"
     :category "ex20: account"
     :description "パスワード失敗回数を数える型"
     :inserts "(define wrong-count 0)\n\n(define (incorrect amount)\n  (set! wrong-count (+ wrong-count 1))\n  (if (>= wrong-count 7)\n      (call-the-cops)\n      \"Incorrect password\"))")
    (:trigger "mcint"
     :category "ex20: monte carlo"
     :description "monte-carloを使う積分見積り"
     :inserts "(define (estimate-integral P x1 x2 y1 y2 trials)\n  (let ((area (* (- x2 x1) (- y2 y1))))\n    (* area\n       (monte-carlo\n        trials\n        (lambda ()\n          (let ((x (random-in-range x1 x2))\n                (y (random-in-range y1 y2)))\n            (P x y)))))))")
    (:trigger "randctl"
     :category "ex20: random"
     :description "generate/resetを持つrand dispatch"
     :inserts "(define rand\n  (let ((x random-init))\n    (lambda (m)\n      (cond ((eq? m 'generate)\n             (set! x (rand-update x))\n             x)\n            ((eq? m 'reset)\n             (lambda (seed)\n               (set! x seed)\n               ???))\n            (else\n             (error \"Unknown request: RAND\" m))))))")
    (:trigger "jointacc"
     :category "ex20: account"
     :description "新パスワードで元口座へ委譲する型"
     :inserts "(define (make-joint acc pass new-pass)\n  (lambda (given-pass m)\n    (if (eq? given-pass new-pass)\n        (acc pass m)\n        (lambda (amount)\n          \"Incorrect password\"))))")
    (:trigger "evalstate"
     :category "ex20: evaluation order"
     :description "評価順の違いを見る状態つき手続き"
     :inserts "(define f\n  (let ((state initial-value))\n    (lambda (x)\n      (let ((result (??? state x)))\n        (set! state (update-state state x))\n        result)))))"))
  "Catalog of Racket study snippets shown in the template help buffer.")

(tempo-define-template
 "racket-define"
 '("(define (" (p "function name: " function) " " (p "arguments: " args) ")" n>
   (p "body: ") n>
   ")")
 "def"
 "Insert a Racket function definition."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-lambda"
 '("(lambda (" (p "arguments: " args) ")" n>
   (p "body: ") n>
   ")")
 "lam"
 "Insert a Racket lambda expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-let"
 '("(let ([" (p "name: " name) " " (p "value: " value) "])" n>
   (p "body: ") n>
   ")")
 "let"
 "Insert a Racket let expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-cond"
 '("(cond" n>
   "[" (p "test: " test) " " (p "result: " result) "]" n>
   "[else " (p "else: ") "])")
 "cond"
 "Insert a Racket cond expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-check-expect"
 '("(check-expect " (p "actual: " actual) " " (p "expected: " expected) ")")
 "check"
 "Insert a check-expect form."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-check-equal"
 '("(check-equal? " (p "actual: " actual) " " (p "expected: " expected) ")")
 "ceq"
 "Insert a rackunit check-equal? form."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-require-rackunit"
 '("(require rackunit)")
 "rack"
 "Insert a rackunit require form."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-list-recursion"
 '("(define (" (p "function name: " function) " " (p "items argument: " items) ")" n>
   "(if (null? " (s items) ")" n>
   "'()" n>
   "(cons (process (car " (s items) "))" n>
   "(" (s function) " (cdr " (s items) ")))))")
 "lrec"
 "Insert an ex14 list recursion pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-list-select"
 '("(define (" (p "selector name: " function) " " (p "items argument: " items) ")" n>
   "(cond ((null? " (s items) ") '())" n>
   "((keep? (car " (s items) "))" n>
   "(cons (car " (s items) ")" n>
   "(" (s function) " (cdr " (s items) "))))" n>
   "(else" n>
   "(" (s function) " (cdr " (s items) ")))))")
 "lsel"
 "Insert an ex14 list selection pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-tree-recursion"
 '("(define (" (p "function name: " function) " " (p "tree argument: " tree) ")" n>
   "(cond ((null? " (s tree) ") '())" n>
   "((not (pair? " (s tree) ")) " (s tree) ")" n>
   "(else" n>
   "(combine (" (s function) " (car " (s tree) "))" n>
   "(" (s function) " (cdr " (s tree) "))))))")
 "trec"
 "Insert an ex14 tree recursion pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-leaf-collector"
 '("(define (" (p "function name: " function) " " (p "tree argument: " tree) ")" n>
   "(cond ((null? " (s tree) ") '())" n>
   "((not (pair? " (s tree) ")) (list " (s tree) "))" n>
   "(else" n>
   "(append (" (s function) " (car " (s tree) "))" n>
   "(" (s function) " (cdr " (s tree) "))))))")
 "leaf"
 "Insert an ex14 leaf-collector pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-foreach-recursion"
 '("(define (" (p "function name: " function) " " (p "procedure argument: " proc) " " (p "items argument: " items) ")" n>
   "(if (null? " (s items) ")" n>
   "'done" n>
   "(begin" n>
   "(" (s proc) " (car " (s items) "))" n>
   "(" (s function) " " (s proc) " (cdr " (s items) ")))))")
 "foreach"
 "Insert an ex14 side-effect recursion pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-varargs-select"
 '("(define (" (p "function name: " function) " " (p "first argument: " first) " . " (p "rest argument: " rest) ")" n>
   "(define (same? x)" n>
   "(same-rule? x " (s first) "))" n>
   "(define (select items)" n>
   "(cond ((null? items) '())" n>
   "((same? (car items))" n>
   "(cons (car items)" n>
   "(select (cdr items))))" n>
   "(else" n>
   "(select (cdr items)))))" n>
   "(cons " (s first) n>
   "(select " (s rest) ")))")
 "varargs"
 "Insert an ex14 variable-argument selection pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-message-dispatch"
 '("(define (" (p "constructor name: " constructor) " " (p "stored values: " values) ")" n>
   "(define (dispatch op)" n>
   "(cond ((eq? op '" (p "first message: " message-a) ") " (p "first result: " result-a) ")" n>
   "((eq? op '" (p "second message: " message-b) ") " (p "second result: " result-b) ")" n>
   "(else" n>
   "(error \"Unknown op\" op))))" n>
   "dispatch)")
 "mpdisp"
 "Insert a review message-passing dispatch pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-deriv-power-branch"
 '("((exponentiation? exp)" n>
   "(make-product" n>
   "(make-product" n>
   "(exponent exp)" n>
   "(make-exponentiation" n>
   "(base exp)" n>
   "(make-sum (exponent exp) -1)))" n>
   "(deriv (base exp) var)))")
 "derivpow"
 "Insert a review exponentiation derivative branch."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-nary-operands"
 '("(define (rest-operand exp op)" n>
   "(let ((rest (cddr exp)))" n>
   "(if (null? (cdr rest))" n>
   "(car rest)" n>
   "(cons op rest))))")
 "nary"
 "Insert a review n-ary sum/product operand pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-ordered-set-merge"
 '("(define (union-set set1 set2)" n>
   "(cond ((null? set1) set2)" n>
   "((null? set2) set1)" n>
   "(else" n>
   "(let ((x1 (car set1))" n>
   "(x2 (car set2)))" n>
   "(cond ((= x1 x2)" n>
   "(cons x1 (union-set (cdr set1) (cdr set2))))" n>
   "((< x1 x2)" n>
   "(cons x1 (union-set (cdr set1) set2)))" n>
   "(else" n>
   "(cons x2 (union-set set1 (cdr set2)))))))))")
 "oset"
 "Insert a review ordered-set merge pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-huffman-encode-symbol"
 '("(define (encode-symbol sym tree)" n>
   "(cond ((leaf? tree) '())" n>
   "((memq sym (symbols (left-branch tree)))" n>
   "(cons 0 (encode-symbol sym (left-branch tree))))" n>
   "((memq sym (symbols (right-branch tree)))" n>
   "(cons 1 (encode-symbol sym (right-branch tree))))" n>
   "(else" n>
   "(error \"symbol not in tree\" sym))))")
 "huff"
 "Insert a review Huffman encode-symbol pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-successive-merge"
 '("(define (successive-merge ordered-trees)" n>
   "(cond ((null? ordered-trees) '())" n>
   "((null? (cdr ordered-trees)) (car ordered-trees))" n>
   "(else" n>
   "(successive-merge" n>
   "(adjoin-set" n>
   "(make-code-tree (car ordered-trees)" n>
   "(cadr ordered-trees))" n>
   "(cddr ordered-trees))))))")
 "smerge"
 "Insert a review Huffman successive-merge pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-apply-generic"
 '("(define (apply-generic op . args)" n>
   "(let ((type-tags (map type-tag args)))" n>
   "(let ((proc (get op type-tags)))" n>
   "(if proc" n>
   "(apply proc (map contents args))" n>
   "(error \"No method for these types: APPLY-GENERIC\"" n>
   "(list op type-tags))))))")
 "applygen"
 "Insert a review apply-generic pattern."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-tagged-data-bare-number"
 '("(define (attach-tag type-tag contents)" n>
   "(if (and (eq? type-tag 'scheme-number)" n>
   "(number? contents))" n>
   "contents" n>
   "(cons type-tag contents)))" n>
   n>
   "(define (type-tag datum)" n>
   "(cond ((number? datum) 'scheme-number)" n>
   "((pair? datum) (car datum))" n>
   "(else (error \"Bad tagged datum: TYPE-TAG\" datum))))" n>
   n>
   "(define (contents datum)" n>
   "(cond ((number? datum) datum)" n>
   "((pair? datum) (cdr datum))" n>
   "(else (error \"Bad tagged datum: CONTENTS\" datum))))")
 "tagged"
 "Insert a review bare scheme-number tagging pattern."
 'my/racket-tempo-tags)

(dolist (snippet my/racket-snippet-catalog)
  (let ((trigger (plist-get snippet :trigger)))
    (when (member trigger
                  '("gbang" "gworld" "gdraw" "gkey" "gtick" "gmouse"
                    "ghit" "ggrid" "rsig" "rpar" "rpipe"
                    "sstream" "sdelay" "smut"
                    "statelet" "msgdisp" "passacc" "badpass"
                    "mcint" "randctl" "jointacc" "evalstate"))
      (tempo-define-template
       (concat "racket-study-" trigger)
       (list (plist-get snippet :inserts))
       trigger
       (plist-get snippet :description)
       'my/racket-tempo-tags))))

(defun my/racket-tempo-setup ()
  "Enable Racket study snippets in the current buffer."
  (tempo-use-tag-list 'my/racket-tempo-tags))

(defun my/racket-template-category-rank (category)
  "Return display rank for template CATEGORY."
  (let ((rank 0)
        found)
    (dolist (known racket-study-template-category-order (or found 999))
      (when (and (not found) (equal known category))
        (setq found rank))
      (setq rank (1+ rank)))))

(defun my/racket-template-catalog-entries ()
  "Return snippet and call-template entries for the help buffer."
  (append
   (mapcar (lambda (snippet)
             (list :display (plist-get snippet :trigger)
                   :category (plist-get snippet :category)
                   :source "スニペット"
                   :description (plist-get snippet :description)
                   :inserts (plist-get snippet :inserts)))
           my/racket-snippet-catalog)
   (mapcar (lambda (item)
             (list :display (plist-get item :display)
                   :category (racket-study--template-category item)
                   :source (format "%s由来"
                                   (racket-study--source-display
                                    (plist-get item :origin)))
                   :description (format "%s を仮引数つきで呼び出す"
                                        (plist-get item :name))
                   :inserts (plist-get item :insert)))
           (racket-study-template-items))))

(defun my/racket-template-categories (entries)
  "Return sorted category names present in ENTRIES."
  (let (categories)
    (dolist (entry entries)
      (cl-pushnew (plist-get entry :category) categories :test #'equal))
    (sort categories
          (lambda (left right)
            (let ((left-rank (my/racket-template-category-rank left))
                  (right-rank (my/racket-template-category-rank right)))
              (if (= left-rank right-rank)
                  (string-lessp left right)
                (< left-rank right-rank)))))))

(defun my/racket-exercise-hint-args (hint)
  "Return a compact argument summary for exercise HINT."
  (if (plist-get hint :args)
      (mapconcat #'identity (plist-get hint :args) ", ")
    "なし"))

(defun my/racket-exercise-hint-related (hint)
  "Return a compact related-function summary for exercise HINT."
  (if (plist-get hint :related)
      (mapconcat #'identity (seq-take (plist-get hint :related) 8) ", ")
    "なし"))

(defun my/racket-exercise-hint-tests (hint)
  "Return a compact tests summary for exercise HINT."
  (racket-study--exercise-tests-summary hint))

(defun my/racket-exercise-hints-for (exercise)
  "Return exercise hints that appear in EXERCISE."
  (sort
   (cl-remove-if-not
    (lambda (hint)
      (member exercise (plist-get hint :exercises)))
    (copy-sequence racket-study-exercise-hints))
   (lambda (left right)
     (string-lessp (plist-get left :name)
                   (plist-get right :name)))))

(defun my/racket-insert-exercise-hints-section ()
  "Insert the exercise hint section into the current buffer."
  (when (and (boundp 'racket-study-exercise-hints)
             racket-study-exercise-hints)
    (insert "演習ヒント\n")
    (insert "==========\n\n")
    (insert "解答全文は表示せず、関数名・引数・出典・関連関数だけを学習用に表示します。\n\n")
    (dolist (exercise '("ex04" "ex06" "ex08" "ex10" "ex12"
                        "ex14" "ex16" "ex20" "ex22"))
      (let ((hints (my/racket-exercise-hints-for exercise)))
        (when hints
          (insert (format "%s\n" exercise))
          (insert (make-string (length exercise) ?-) "\n")
          (insert "関数                   分類                         引数\n")
          (dolist (hint hints)
            (insert (format "%-22s %-28s %s\n"
                            (plist-get hint :name)
                            (plist-get hint :category-ja)
                            (my/racket-exercise-hint-args hint)))
            (insert (format "  出典: %s\n"
                            (racket-study--exercise-source-summary hint)))
            (insert (format "  関連関数: %s / テスト: %s\n"
                            (my/racket-exercise-hint-related hint)
                            (my/racket-exercise-hint-tests hint))))
          (insert "\n"))))))

(defun my/racket-ex14-front-items ()
  "Return ex14 front-half study pattern and answer items."
  (cl-remove-if-not
   (lambda (item)
     (memq (plist-get item :kind) '(ex14-pattern ex14-answer)))
   racket-study-completion-items))

(defun my/racket-insert-ex14-front-section ()
  "Insert the ex14 front-half study section into the current buffer."
  (let* ((items (my/racket-ex14-front-items))
         (patterns (cl-remove-if-not
                    (lambda (item) (eq (plist-get item :kind) 'ex14-pattern))
                    items))
         (answers (cl-remove-if-not
                   (lambda (item) (eq (plist-get item :kind) 'ex14-answer))
                   items)))
    (when items
      (insert "ex14前半: リスト・木構造の型\n")
      (insert "==============================\n\n")
      (insert "list は横に進み、tree は中にもぐります。型テンプレートは骨組み、=ex14 は模範解答を挿入します。\n\n")
      (insert "型テンプレート\n")
      (insert "--------------\n")
      (insert "候補                   型                         覚えるポイント\n")
      (dolist (item patterns)
        (insert (format "%-22s %-26s %s\n"
                        (plist-get item :name)
                        (or (plist-get item :pattern-type) "")
                        (or (plist-get item :remember) "")))
        (insert (format "  使う場面: %s\n"
                        (or (plist-get item :use) ""))))
      (insert "\n模範解答候補\n")
      (insert "------------\n")
      (insert "候補                   対象関数                   型\n")
      (dolist (item answers)
        (insert (format "%-22s %-26s %s\n"
                        (plist-get item :name)
                        (or (plist-get item :answer-name) "")
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  ポイント: %s\n"
                        (or (plist-get item :remember) ""))))
      (insert "\n"))))

(defun my/racket-review-items ()
  "Return review 07/08 study pattern and answer items."
  (cl-remove-if-not
   (lambda (item)
     (memq (plist-get item :kind) '(review-pattern review-answer)))
   racket-study-completion-items))

(defun my/racket-review-item-less-p (left right)
  "Return non-nil when LEFT should be listed before RIGHT."
  (let ((left-category (racket-study--template-category left))
        (right-category (racket-study--template-category right)))
    (if (equal left-category right-category)
        (string-lessp (plist-get left :name)
                      (plist-get right :name))
      (< (my/racket-template-category-rank left-category)
         (my/racket-template-category-rank right-category)))))

(defun my/racket-insert-review-section ()
  "Insert the review 07/08 study section into the current buffer."
  (let* ((items (my/racket-review-items))
         (patterns (sort
                    (cl-remove-if-not
                     (lambda (item) (eq (plist-get item :kind) 'review-pattern))
                     (copy-sequence items))
                    #'my/racket-review-item-less-p))
         (answers (sort
                   (cl-remove-if-not
                    (lambda (item) (eq (plist-get item :kind) 'review-answer))
                    (copy-sequence items))
                   #'my/racket-review-item-less-p)))
    (when items
      (insert "復習07/08: 記号処理・データ主導の型\n")
      (insert "====================================\n\n")
      (insert "記号微分、整列集合、ハフマン木、メッセージパッシング、データ主導、ジェネリック演算を用途別に見返せます。\n\n")
      (insert "型テンプレート\n")
      (insert "--------------\n")
      (insert "候補                       分類                         型\n")
      (dolist (item patterns)
        (insert (format "%-26s %-28s %s\n"
                        (plist-get item :name)
                        (racket-study-template-category-label
                         (racket-study--template-category item))
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  使う場面: %s\n"
                        (or (plist-get item :use) "")))
        (insert (format "  ポイント: %s\n"
                        (or (plist-get item :remember) ""))))
      (insert "\n模範解答候補\n")
      (insert "------------\n")
      (insert "候補                       対象関数                     型\n")
      (dolist (item answers)
        (insert (format "%-26s %-28s %s\n"
                        (plist-get item :name)
                        (or (plist-get item :answer-name) "")
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  出典: %s / ポイント: %s\n"
                        (or (plist-get item :source) "")
                        (or (plist-get item :remember) ""))))
      (insert "\n"))))

(defun my/racket-ex20-items ()
  "Return ex20 study pattern and call helper items."
  (cl-remove-if-not
   (lambda (item)
     (memq (plist-get item :kind) '(ex20-pattern ex20-call)))
   racket-study-completion-items))

(defun my/racket-ex20-item-less-p (left right)
  "Return non-nil when LEFT should be listed before RIGHT."
  (let ((left-category (racket-study--template-category left))
        (right-category (racket-study--template-category right)))
    (if (equal left-category right-category)
        (string-lessp (plist-get left :name)
                      (plist-get right :name))
      (< (my/racket-template-category-rank left-category)
         (my/racket-template-category-rank right-category)))))

(defun my/racket-insert-ex20-section ()
  "Insert the ex20 state and assignment study section."
  (let* ((items (sort (copy-sequence (my/racket-ex20-items))
                      #'my/racket-ex20-item-less-p))
         (patterns (cl-remove-if-not
                    (lambda (item) (eq (plist-get item :kind) 'ex20-pattern))
                    items))
         (calls (cl-remove-if-not
                 (lambda (item) (eq (plist-get item :kind) 'ex20-call))
                 items)))
    (when items
      (insert "ex20: 状態・クロージャ・代入\n")
      (insert "===========================\n\n")
      (insert "教科書練習問題3.1〜3.8向けに、解答全文ではなく状態を持つ処理の型だけを整理しています。\n\n")
      (insert "型テンプレート\n")
      (insert "--------------\n")
      (insert "候補                              問題       型\n")
      (dolist (item patterns)
        (insert (format "%-33s %-10s %s\n"
                        (plist-get item :name)
                        (or (plist-get item :exercise) "")
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  使う場面: %s\n"
                        (or (plist-get item :use) "")))
        (insert (format "  テスト条件: %s\n"
                        (or (plist-get item :tests) "")))
        (insert (format "  よくあるミス: %s\n"
                        (or (plist-get item :mistake) ""))))
      (when calls
        (insert "\n呼び出し補助\n")
        (insert "------------\n")
        (insert "候補                              問題       挿入内容\n")
        (dolist (item calls)
          (insert (format "%-33s %-10s %s\n"
                          (or (plist-get item :display)
                              (plist-get item :name))
                          (or (plist-get item :exercise) "")
                          (or (plist-get item :insert) "")))
          (insert (format "  ポイント: %s\n"
                          (or (plist-get item :remember) "")))))
      (insert "\n"))))

(defun my/racket-game-study-items ()
  "Return game and Reactor study completion items."
  (cl-remove-if-not
   (lambda (item)
     (memq (plist-get item :kind)
           '(game-pattern game-example reactor-pattern)))
   racket-study-completion-items))

(defun my/racket-insert-game-study-section ()
  "Insert game creation and Reactor sections into the current buffer."
  (let* ((items (my/racket-game-study-items))
         (game-items
          (cl-remove-if-not
           (lambda (item)
             (memq (plist-get item :kind) '(game-pattern game-example)))
           items))
         (reactor-items
          (cl-remove-if-not
           (lambda (item)
             (eq (plist-get item :kind) 'reactor-pattern))
           items)))
    (when game-items
      (insert "ゲーム作成: 2htdp/image・2htdp/universe\n")
      (insert "========================================\n\n")
      (insert "ex18・shooting・sugoroku・quest・reversiから、再利用しやすい型だけを整理しています。\n\n")
      (dolist (item game-items)
        (insert (format "%-26s %-28s %s\n"
                        (plist-get item :name)
                        (racket-study-template-category-label
                         (racket-study--template-category item))
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  使う場面: %s\n"
                        (or (plist-get item :use) "")))
        (insert (format "  ポイント: %s\n"
                        (or (plist-get item :remember) ""))))
      (insert "\n"))
    (when reactor-items
      (insert "Reactor: signal・並行処理・ストリーム\n")
      (insert "====================================\n\n")
      (insert "reactor.zipのsignal処理を、送受信・並行・中断・map/filter/accumulateに分けています。\n\n")
      (dolist (item reactor-items)
        (insert (format "%-26s %-28s %s\n"
                        (plist-get item :name)
                        (racket-study-template-category-label
                         (racket-study--template-category item))
                        (or (plist-get item :pattern-type) "")))
        (insert (format "  使う場面: %s\n"
                        (or (plist-get item :use) "")))
        (insert (format "  ポイント: %s\n"
                        (or (plist-get item :remember) ""))))
      (insert "\n"))))

(defun my/racket-study-templates-buffer ()
  "Build and return the Racket study template help buffer."
  (let ((buffer (get-buffer-create "*Racket Study Templates*"))
        (entries (my/racket-template-catalog-entries)))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert "Racket 学習テンプレート\n")
        (insert "======================\n\n")
        (insert "スニペットは C-c s から展開できます。補完テンプレートは name() の形で表示されます。\n\n")
        (dolist (category (my/racket-template-categories entries))
          (let ((category-entries
                 (sort (cl-remove-if-not
                        (lambda (entry)
                          (equal (plist-get entry :category) category))
                        (copy-sequence entries))
                        (lambda (left right)
                          (string-lessp (plist-get left :display)
                                        (plist-get right :display))))))
            (let ((category-label
                   (racket-study-template-category-label category)))
              (insert (format "%s\n" category-label))
              (insert (make-string (length category-label) ?-) "\n"))
            (insert "候補                   出典           説明\n")
            (dolist (entry category-entries)
              (insert (format "%-22s %-14s %s\n"
                              (plist-get entry :display)
                              (plist-get entry :source)
                              (plist-get entry :description)))
              (insert (format "  挿入内容: %s\n" (plist-get entry :inserts))))
            (insert "\n")))
        (my/racket-insert-ex14-front-section)
        (my/racket-insert-review-section)
        (my/racket-insert-ex20-section)
        (my/racket-insert-game-study-section)
        (my/racket-insert-exercise-hints-section)
        (goto-char (point-min))
        (special-mode)))
    buffer))

(defun my/racket-study-show-templates ()
  "Show a categorized help buffer for Racket study templates."
  (interactive)
  (pop-to-buffer (my/racket-study-templates-buffer)))

(defun my/racket-format-buffer ()
  "Indent the current Racket buffer."
  (interactive)
  (when (derived-mode-p 'racket-mode)
    (save-mark-and-excursion
      (save-restriction
        (widen)
        (let ((inhibit-message t))
          (indent-region (point-min) (point-max)))))))

(defun my/racket-format-buffer-before-save ()
  "Indent Racket buffers before saving when enabled."
  (when (and my/racket-format-on-save
             (derived-mode-p 'racket-mode)
             (not buffer-read-only))
    (my/racket-format-buffer)))

(defun my/racket-toggle-format-on-save ()
  "Toggle automatic Racket indentation before save in this buffer."
  (interactive)
  (setq-local my/racket-format-on-save (not my/racket-format-on-save))
  (message "Racket format on save: %s"
           (if my/racket-format-on-save "on" "off")))

(defun my/racket-company-setup ()
  "Prefer Racket-aware completion candidates."
  (when (boundp 'company-backends)
    (setq-local company-backends
                (append (when (fboundp 'company-racket-study)
                          '(company-racket-study))
                        '(company-capf
                          company-files
                          company-dabbrev-code
                          company-keywords
                          company-dabbrev))))
  (when (fboundp 'company-mode)
    (company-mode 1)))

(defun my/racket-associated-repl-buffer ()
  "Return the REPL buffer associated with the current Racket buffer."
  (or (and (boundp 'racket-repl-buffer-name)
           (stringp racket-repl-buffer-name)
           (get-buffer racket-repl-buffer-name))
      (cl-find-if
       (lambda (buffer)
         (with-current-buffer buffer
           (derived-mode-p 'racket-repl-mode)))
       (buffer-list))))

(defun my/racket-sync-repl-language-profile ()
  "Copy the source buffer's Racket/SICP completion profile to its REPL."
  (let ((profile (racket-study-current-language-profile))
        (repl-buffer (my/racket-associated-repl-buffer)))
    (when (buffer-live-p repl-buffer)
      (with-current-buffer repl-buffer
        (setq-local racket-study-language-profile profile)))))

(defun my/racket-insert-lang-line ()
  "Insert a starter language line for new empty .rkt files."
  (when (and buffer-file-name
             (string-match-p "\\.rkt\\'" buffer-file-name)
             (not (file-exists-p buffer-file-name))
             (= (buffer-size) 0))
    (insert "#lang racket\n\n")))

(defun my/racket-mode-setup ()
  "Enable a small Racket learning setup."
  (my/racket-insert-lang-line)
  (racket-xp-mode 1)
  (racket-input-mode 1)
  (my/racket-tempo-setup)
  (add-hook 'before-save-hook #'my/racket-format-buffer-before-save nil t)
  (my/racket-company-setup))

(use-package racket-mode
  :mode "\\.rkt\\'"
  :custom
  (racket-program "racket.exe")
  (racket-xp-eldoc-level 'summary)
  (racket-error-context 'medium)
  :bind
  (:map racket-mode-map
        ("C-c r r" . racket-run)
        ("C-c r R" . racket-run-and-switch-to-repl)
        ("C-c r t" . racket-test)
        ("C-c r e" . racket-send-definition)
        ("C-c r x" . racket-send-last-sexp)
        ("C-c r d" . racket-xp-describe)
        ("C-c r h" . racket-documentation-search)
        ("C-c r n" . racket-xp-next-error)
        ("C-c r p" . racket-xp-previous-error)
        ("C-c r ?" . my/racket-study-show-templates)
        ("C-c r f" . my/racket-toggle-format-on-save)
        ("C-c s" . tempo-complete-tag))
  :config
  (require 'racket-input)
  (require 'racket-repl)
  (require 'racket-xp)

  (add-hook 'racket-mode-hook #'my/racket-mode-setup)
  (add-hook 'racket-after-run-hook #'my/racket-sync-repl-language-profile)
  (add-hook 'racket-repl-mode-hook #'my/racket-company-setup))

(with-eval-after-load 'racket-repl
  (keymap-set racket-repl-mode-map "(" #'my/sp-wrap-or-insert-paren)
  (keymap-set racket-repl-mode-map "[" #'my/sp-wrap-or-insert-bracket)
  (add-hook 'racket-repl-mode-hook #'my/racket-company-setup))

;; Start from home directory
(setq inhibit-startup-screen t)
(cd "~")

;; Default font
(cond
 ((eq system-type 'darwin)
  (set-face-attribute 'default nil
                      :family "PlemolJP Console NF"
                      :foundry "outline"
                      :slant 'normal
                      :weight 'regular
                      :height 220
                      :width 'normal))
 ((eq system-type 'windows-nt)
  (set-face-attribute 'default nil
                      :family "Consolas" ; customize here
                      :foundry "outline"
                      :slant 'normal
                      :weight 'regular
                      :height 130        ; customize here
                      :width 'normal)))

(message "ALL DONE.")
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(package-selected-packages nil))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(page-break-lines ((t (:foreground "gray30" :family "Courier" :height 1)))))


(provide 'init)
;;; init.el ends here
