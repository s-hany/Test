# 大学PC Emacs/Racket ゲーム・SICP・ex20更新手順

## 前提

- 大学PCに前回のEmacs/Racket学習設定が入っていること
- Emacs 30.2とRacket 9.1が利用できること
- Racketパッケージ導入時にインターネットへ接続できること

## 更新

1. 大学PCの `%USERPROFILE%\.emacs.d\init.el` と `racket-study-completions.el` をバックアップします。
2. このzipの `.emacs.d` にある2ファイルを、大学PCの `%USERPROFILE%\.emacs.d` へ上書きします。
3. `install-racket-packages-online.bat` を実行して `sicp` と `reactor` を導入します。
4. Emacsを再起動します。

## 主な機能

- `#lang racket`: ex20、ゲームAPI、ゲームの型、Reactor、従来の学習補完
- `#lang sicp`: ex20、SICP互換候補、stream、遅延評価、従来のSICP演習補完
- ex20補完: `state-closure`, `password-account-dispatch`, `rand-reset-dispatch`, `evaluation-order-state` など
- `C-c s`: スニペット。`statelet`, `passacc`, `mcint`, `randctl`, `evalstate`, `gbang`, `rsig`, `sstream` など
- `C-c r ?`: ex20・ゲーム・Reactor・SICPを含むテンプレート一覧
- `C-c r f`: 保存時自動整列の切替

新規 `.rkt` の初期言語は従来どおり `#lang racket` です。SICPで書く場合は先頭を `#lang sicp` に変更してください。

## 確認

```racket
#lang sicp
(define s (cons-stream 1 the-empty-stream))
(car s)
```

ex20では、解答全文ではなく「状態・クロージャ・代入」の型テンプレートを補完に出します。ゲームでは `#lang racket` とし、`(require 2htdp/image)`、`(require 2htdp/universe)` を使用します。