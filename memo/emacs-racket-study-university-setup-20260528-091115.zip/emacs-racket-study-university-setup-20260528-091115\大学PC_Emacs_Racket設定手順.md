# 大学PCへの Emacs + Racket 学習用設定 導入手順

このZIPには、現在の個人PCで使っているRacket学習向けEmacs設定を、大学PCへ移すための一式が入っています。

## 入っているもの

```text
.emacs.d/
  init.el
  racket-study-completions.el
  racket-study-exercise-hints.el
  elpa/
start-emacs-with-home.bat
MANIFEST_SHA256.txt
```

- `init.el`: Emacs本体の設定、Racket用キー、スニペット、保存時整列など。
- `racket-study-completions.el`: 標準関数、授業用define候補、呼び出しテンプレート、補完doc。
- `racket-study-exercise-hints.el`: 演習由来の学習ヒント。解答本文は入っていません。
- `elpa/`: `company`, `racket-mode`, `smartparens` などのEmacsパッケージ。
- `start-emacs-with-home.bat`: `HOME` を一時的に大学PCのユーザーフォルダへ寄せてEmacsを起動する補助bat。

## 事前確認

大学PCで以下を確認してください。

1. 大学の利用規約上、ユーザーフォルダ内に設定ファイルを置いてよいこと。
2. Emacs が使えること。
3. Racket が使えること。

PowerShell またはコマンドプロンプトで確認します。

```powershell
emacs --version
racket --version
```

`racket --version` が動かない場合は、Racketが未インストールか、PATHが通っていません。大学PCにRacketが入っていてもPATHにない場合は、`.emacs.d/init.el` の次の設定を実際の場所に合わせます。

```elisp
(racket-program "racket.exe")
```

例:

```elisp
(racket-program "C:/Program Files/Racket/Racket.exe")
```

## 導入手順

1. ZIPを展開します。
2. 大学PCのユーザーフォルダを確認します。

```powershell
echo $env:USERPROFILE
```

通常は次のような場所です。

```text
C:\Users\<大学PCのユーザー名>
```

3. 既存の `.emacs.d` がある場合は、必要に応じて退避します。

```powershell
Rename-Item "$env:USERPROFILE\.emacs.d" ".emacs.d.backup"
```

4. ZIP内の `.emacs.d` フォルダを、大学PCのユーザーフォルダ直下へコピーします。

コピー後の形:

```text
C:\Users\<大学PCのユーザー名>\.emacs.d\init.el
C:\Users\<大学PCのユーザー名>\.emacs.d\racket-study-completions.el
C:\Users\<大学PCのユーザー名>\.emacs.d\racket-study-exercise-hints.el
C:\Users\<大学PCのユーザー名>\.emacs.d\elpa\
```

## HOMEの設定

Emacsが `~/.emacs.d/init.el` を読むために、`HOME` がユーザーフォルダを指している必要があります。

可能なら、ユーザー環境変数に設定します。

```powershell
[Environment]::SetEnvironmentVariable("HOME", $env:USERPROFILE, "User")
```

設定後、Emacsやターミナルを開き直してください。

大学PCで環境変数を変更できない場合は、同梱の `start-emacs-with-home.bat` からEmacsを起動してください。

## 使える機能

`.rkt` ファイルを開くと、Racket向けの補完と学習支援が使えます。

- 標準関数補完: `map`, `filter`, `foldl`, `string-split`, `hash-ref` など。
- define候補: 未定義なら `square [define: ...]` のようにdefine全文を挿入。
- 呼び出しテンプレート: `make-segment()` のような候補で `(make-segment start end)` を挿入。
- 演習ヒント: 解答本文ではなく、関数名、引数、出典、関連関数、テスト数だけを表示。
- 補完doc: 補完候補選択中に `C-d` で説明を確認。
- テンプレート一覧: `C-c r ?` で `*Racket Study Templates*` を表示。
- スニペット: `C-c s` から `def`, `lam`, `let`, `cond`, `check`, `ceq`, `rack` を展開。
- 保存時整列: Racketバッファのみ保存時に自動インデント。`C-c r f` でON/OFF切り替え。

## 動作確認

Emacsを起動して、新しい `.rkt` ファイルを開きます。

確認例:

- `map` が `[builtin: ...]` として出る。
- `square` が未定義時は `[define: ...]` として出る。
- `make-segment()` を選ぶと `(make-segment start end)` の形で入る。
- `cube-root` などが `[exercise hint]` として出る。
- `C-c r ?` で日本語のテンプレート一覧が開く。
- `C-c s` でスニペット候補が出る。

Racket用キーの例:

```text
C-c r r  実行
C-c r R  実行してREPLへ移動
C-c r t  テスト
C-c r e  定義をREPLへ送信
C-c r x  直前の式をREPLへ送信
C-c r d  説明
C-c r h  ドキュメント検索
C-c r ?  テンプレート・学習ヒント一覧
C-c r f  保存時整列ON/OFF
C-c s    スニペット補完
```

## うまく動かないとき

- Emacsが設定を読まない場合: `HOME` がユーザーフォルダを指しているか確認してください。
- 補完が出ない場合: `.rkt` ファイルを開いているか、`M-/` を押して補完を明示実行してください。
- Racket実行ができない場合: `racket --version` が通るか確認してください。
- 既存設定と混ざって不安定な場合: 既存 `.emacs.d` を退避して、このZIPの `.emacs.d` だけで起動してください。