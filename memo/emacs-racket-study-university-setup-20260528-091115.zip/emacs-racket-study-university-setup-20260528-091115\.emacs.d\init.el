;;; init.el --- Emacs configuration -*- lexical-binding: t -*-
;;; Commentary:
;;; Code:

(when (eq system-type 'darwin)
  (setq mac-command-modifier 'meta))

(prefer-coding-system 'utf-8)

(setq x-select-enable-clipboard t
      x-select-enable-primary t
      save-interprogram-paste-before-kill t
      apropos-do-all t
      mouse-yank-at-point t)

;; 警告音と画面フラッシュが鬱陶しいため無効化
(setq ring-bell-function 'ignore)

;; Emacsチュートリアル
(keymap-set global-map "C-h t" #'help-with-tutorial-spec-language)
;; 操作に慣れてきたら，以下の2行のコメントアウトを外すのがおすすめ
;; （C-hは直前の1文字の削除．ヘルプはM-hで開く．）
;; (keymap-global-set "C-h" #'delete-backward-char)
;; (keymap-global-set "M-h" #'help)

;; コマンド履歴を保存
(savehist-mode 1)
;; ファイル内のカーソル位置を記憶
(save-place-mode 1)

;; インデントにタブ文字を使わない
(setq-default indent-tabs-mode nil)

;; オープン中のバッファが他所で変更された際の同期処理
(global-auto-revert-mode 1)
;; Dired等も自動更新
(setq global-auto-revert-non-file-buffers t)

;; Emacs中のファイル削除は「ごみ箱へ移動」
(setq delete-by-moving-to-trash t)

;; フレームやウィンドウのリサイズをスムーズに
(setq window-resize-pixelwise t)
(setq frame-resize-pixelwise t)

;; スクロールもスムーズに
(pixel-scroll-precision-mode 1)

;; マウソポインタの位置に追随して自動でウィンドウをセレクト
(setq mouse-autoselect-window t)

;; マウスのドラッグ＆ドロップでリージョンのコピペを可能に
;; Emacs以外へもコピペ可能にする
(setq mouse-drag-and-drop-region-cross-program t)
;; Metaキーを押しながらドロップ = 同一バッファ内でも移動ではなくコピー
(setq mouse-drag-and-drop-region 'meta)

;; グローバルなフォントスケーリングにフレームサイズを追随
(setq global-text-scale-adjust-resizes-frames t)

;; ツールバー不要
(tool-bar-mode -1)
;; メニューバー不要
(menu-bar-mode -1)

;; ウィンドウの縁を掴めるようにする
(window-divider-mode)
(setq-default window-divider-default-right-width 1)

;; 初期フレームサイズ
(add-to-list 'default-frame-alist '(width . 83))
(add-to-list 'default-frame-alist '(height . 36))
;; 80文字目に罫線
;; (setq-default display-fill-column-indicator-column 80)
;; (global-display-fill-column-indicator-mode)

;; カーソルの見た目
(setq-default cursor-type '(bar . 3))
(blink-cursor-mode -1)

;; ウィンドウの横幅を超える行を自動で折り返す
(setq-default truncate-lines nil)

;; シンタックス・ハイライト
(setq font-lock-maximum-decoration t)

;; 括弧の対応を強調表示
(show-paren-mode t)

;; 現在行をハイライト表示
;; (global-hl-line-mode t)

;; モードラインにカラムを表示
(column-number-mode t)

;; delete selection modeを有効化
(delete-selection-mode)

;; minibufferのdefaultをスマート化
(minibuffer-electric-default-mode)

;; Ctrl+マウスホイール（トラックパッド含む）による
;; text-scale-adjustの誤爆を防止
(global-unset-key (kbd "C-<wheel-up>"))
(global-unset-key (kbd "C-<wheel-down>"))
(global-unset-key (kbd "C-<mouse-4>"))
(global-unset-key (kbd "C-<mouse-5>"))


;; External packages

(use-package package
  :config
  (add-to-list 'package-archives
               '("melpa" . "https://melpa.org/packages/"))
  ;; (package-initialize)
  )

(setopt use-package-always-ensure t)
(setopt package-native-compile nil)
;; (setopt warning-minimum-level :emergency)

(use-package use-package
  :ensure nil)

;; PC room only
;; (unless (package-installed-p 'compat)
;;   (package-install-file "~/.emacs.d/compat-30.1.0.1.0.20260131.205608.tar"))
;; (use-package compat
;;   :ensure nil)

;; org-modern
(use-package org-modern
  :after org
  :hook
  ((org-mode . org-indent-mode)
   (org-mode . org-modern-mode)
   (org-agenda-finalize-hook . org-modern-agenda))
  :config
  (defun my/org-indent-redraw ()
    "Force redraw of org-indent overlays."
    (interactive)
    (org-indent-mode -1)
    (org-indent-mode 1))
  :bind
  (:map org-mode-map
        ("C-c i" . my/org-indent-redraw)))

;; Display page-break (\f, C-q C-l) as a horizontal line
(use-package page-break-lines
  :config
  (add-to-list 'page-break-lines-modes 'racket-mode)
  (custom-set-faces
   '(page-break-lines ((t (:foreground "gray30" :family "Courier" :height 1)))))
  (setq page-break-lines-max-width (if (eq system-type 'windows-nt) 40 68))
  (global-page-break-lines-mode 1))

;; Smart minibuffer
(use-package vertico
  :init
  (vertico-mode)
  :custom
  (vertico-sort-function 'vertico-sort-history-alpha))
;; Search for partial matches in any order
(use-package orderless
  :custom
  (completion-styles '(orderless basic))
  (completion-category-defaults nil)
  (completion-category-overrides
   '((file (styles partial-completion)))))
;; Enable richer annotations using the Marginalia package
(use-package marginalia
  :init
  (marginalia-mode))
;; Improve keyboard shortcut discoverability
(use-package which-key
  :config
  (which-key-mode)
  :custom
  (which-key-max-description-length 40)
  (which-key-lighter nil)
  (which-key-sort-order 'which-key-description-order))

;; Auto-comletion for all mode
(use-package company
  :demand t
  :custom
  (company-idle-delay 0.05)
  (company-minimum-prefix-length 1)
  (company-tooltip-align-annotations t)
  (company-selection-wrap-around t)
  :bind
  ("M-/" . company-complete)
  (:map company-active-map
        ("C-n" . company-select-next)
        ("C-p" . company-select-previous)
        ("<tab>" . company-complete-selection)
        ("C-d" . company-show-doc-buffer)
        ("M-." . company-show-location))
  :config
  (global-company-mode 1))

;; Tiny documentation in echo area
(use-package eldoc-mouse
  :custom
  (eldoc-mouse-posframe-max-width 80)
  (eldoc-mouse-posframe-max-height 16)
  ;; (eldoc-mouse-idle-time 1.2) ;; default = 0.4
  :hook eldoc-mode)

;; Appearance
(use-package modus-themes
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts t)
  (modus-themes-to-toggle '(modus-operandi-tinted
			    modus-vivendi-tinted))
  :bind
  (("C-c t t" . modus-themes-toggle)
   ("C-c t m" . modus-themes-select)))
;(use-package ef-themes)
(use-package doom-themes)
(load-theme 'modus-vivendi-tinted t) ; change here

;; Paren editing
(use-package smartparens
  :config
  (require 'smartparens-config)
  (smartparens-global-mode t)
  (setq sp-highlight-pair-overlay nil
        sp-highlight-wrap-overlay nil
        sp-highlight-wrap-tag nil
        sp-autowrap-region t)
  :hook ((prog-mode . smartparens-mode) ;; smartparens-strict-mode
         (eval-expression-minibuffer-setup . smartparens-mode))
  :bind (:map sp-keymap
              ;; ("M-s" . nil)
              ("M-]" . sp-forward-slurp-sexp)
              ("M-[" . sp-forward-barf-sexp)))

;; Racket mode
(load (locate-user-emacs-file "racket-study-completions.el") t)
(require 'tempo)

(defvar my/racket-format-on-save t
  "When non-nil, indent Racket buffers before saving.")

(defvar my/racket-tempo-tags nil
  "Tempo snippets for Racket study buffers.")

(defconst my/racket-snippet-catalog
  '((:trigger "def"
     :category "definition"
     :description "関数定義"
     :inserts "(define (name args)\n  body)")
    (:trigger "lam"
     :category "function call"
     :description "無名関数"
     :inserts "(lambda (args)\n  body)")
    (:trigger "let"
     :category "local binding"
     :description "局所束縛"
     :inserts "(let ([name value])\n  body)")
    (:trigger "cond"
     :category "conditional"
     :description "条件分岐"
     :inserts "(cond\n  [test result]\n  [else value])")
    (:trigger "check"
     :category "test"
     :description "check-expect テスト"
     :inserts "(check-expect actual expected)")
    (:trigger "ceq"
     :category "test"
     :description "rackunit の check-equal?"
     :inserts "(check-equal? actual expected)")
    (:trigger "rack"
     :category "test"
     :description "rackunit を読み込む"
     :inserts "(require rackunit)"))
  "Catalog of Racket study snippets shown in the template help buffer.")

(tempo-define-template
 "racket-define"
 '("(define (" (p "function name: " function) " " (p "arguments: " args) ")" n>
   (p "body: ") n>
   ")")
 "def"
 "Insert a Racket function definition."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-lambda"
 '("(lambda (" (p "arguments: " args) ")" n>
   (p "body: ") n>
   ")")
 "lam"
 "Insert a Racket lambda expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-let"
 '("(let ([" (p "name: " name) " " (p "value: " value) "])" n>
   (p "body: ") n>
   ")")
 "let"
 "Insert a Racket let expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-cond"
 '("(cond" n>
   "[" (p "test: " test) " " (p "result: " result) "]" n>
   "[else " (p "else: ") "])")
 "cond"
 "Insert a Racket cond expression."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-check-expect"
 '("(check-expect " (p "actual: " actual) " " (p "expected: " expected) ")")
 "check"
 "Insert a check-expect form."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-check-equal"
 '("(check-equal? " (p "actual: " actual) " " (p "expected: " expected) ")")
 "ceq"
 "Insert a rackunit check-equal? form."
 'my/racket-tempo-tags)

(tempo-define-template
 "racket-require-rackunit"
 '("(require rackunit)")
 "rack"
 "Insert a rackunit require form."
 'my/racket-tempo-tags)

(defun my/racket-tempo-setup ()
  "Enable Racket study snippets in the current buffer."
  (tempo-use-tag-list 'my/racket-tempo-tags))

(defun my/racket-template-category-rank (category)
  "Return display rank for template CATEGORY."
  (let ((rank 0)
        found)
    (dolist (known racket-study-template-category-order (or found 999))
      (when (and (not found) (equal known category))
        (setq found rank))
      (setq rank (1+ rank)))))

(defun my/racket-template-catalog-entries ()
  "Return snippet and call-template entries for the help buffer."
  (append
   (mapcar (lambda (snippet)
             (list :display (plist-get snippet :trigger)
                   :category (plist-get snippet :category)
                   :source "スニペット"
                   :description (plist-get snippet :description)
                   :inserts (plist-get snippet :inserts)))
           my/racket-snippet-catalog)
   (mapcar (lambda (item)
             (list :display (plist-get item :display)
                   :category (racket-study--template-category item)
                   :source (format "%s由来"
                                   (racket-study--source-display
                                    (plist-get item :origin)))
                   :description (format "%s を仮引数つきで呼び出す"
                                        (plist-get item :name))
                   :inserts (plist-get item :insert)))
           (racket-study-template-items))))

(defun my/racket-template-categories (entries)
  "Return sorted category names present in ENTRIES."
  (let (categories)
    (dolist (entry entries)
      (cl-pushnew (plist-get entry :category) categories :test #'equal))
    (sort categories
          (lambda (left right)
            (let ((left-rank (my/racket-template-category-rank left))
                  (right-rank (my/racket-template-category-rank right)))
              (if (= left-rank right-rank)
                  (string-lessp left right)
                (< left-rank right-rank)))))))

(defun my/racket-exercise-hint-args (hint)
  "Return a compact argument summary for exercise HINT."
  (if (plist-get hint :args)
      (mapconcat #'identity (plist-get hint :args) ", ")
    "なし"))

(defun my/racket-exercise-hint-related (hint)
  "Return a compact related-function summary for exercise HINT."
  (if (plist-get hint :related)
      (mapconcat #'identity (seq-take (plist-get hint :related) 8) ", ")
    "なし"))

(defun my/racket-exercise-hint-tests (hint)
  "Return a compact tests summary for exercise HINT."
  (racket-study--exercise-tests-summary hint))

(defun my/racket-exercise-hints-for (exercise)
  "Return exercise hints that appear in EXERCISE."
  (sort
   (cl-remove-if-not
    (lambda (hint)
      (member exercise (plist-get hint :exercises)))
    (copy-sequence racket-study-exercise-hints))
   (lambda (left right)
     (string-lessp (plist-get left :name)
                   (plist-get right :name)))))

(defun my/racket-insert-exercise-hints-section ()
  "Insert the exercise hint section into the current buffer."
  (when (and (boundp 'racket-study-exercise-hints)
             racket-study-exercise-hints)
    (insert "演習ヒント\n")
    (insert "==========\n\n")
    (insert "解答全文は表示せず、関数名・引数・出典・関連関数だけを学習用に表示します。\n\n")
    (dolist (exercise '("ex04" "ex06" "ex08" "ex10" "ex12"
                        "ex14" "ex16" "ex20" "ex22"))
      (let ((hints (my/racket-exercise-hints-for exercise)))
        (when hints
          (insert (format "%s\n" exercise))
          (insert (make-string (length exercise) ?-) "\n")
          (insert "関数                   分類                         引数\n")
          (dolist (hint hints)
            (insert (format "%-22s %-28s %s\n"
                            (plist-get hint :name)
                            (plist-get hint :category-ja)
                            (my/racket-exercise-hint-args hint)))
            (insert (format "  出典: %s\n"
                            (racket-study--exercise-source-summary hint)))
            (insert (format "  関連関数: %s / テスト: %s\n"
                            (my/racket-exercise-hint-related hint)
                            (my/racket-exercise-hint-tests hint))))
          (insert "\n"))))))

(defun my/racket-study-templates-buffer ()
  "Build and return the Racket study template help buffer."
  (let ((buffer (get-buffer-create "*Racket Study Templates*"))
        (entries (my/racket-template-catalog-entries)))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert "Racket 学習テンプレート\n")
        (insert "======================\n\n")
        (insert "スニペットは C-c s から展開できます。補完テンプレートは name() の形で表示されます。\n\n")
        (dolist (category (my/racket-template-categories entries))
          (let ((category-entries
                 (sort (cl-remove-if-not
                        (lambda (entry)
                          (equal (plist-get entry :category) category))
                        (copy-sequence entries))
                        (lambda (left right)
                          (string-lessp (plist-get left :display)
                                        (plist-get right :display))))))
            (let ((category-label
                   (racket-study-template-category-label category)))
              (insert (format "%s\n" category-label))
              (insert (make-string (length category-label) ?-) "\n"))
            (insert "候補                   出典           説明\n")
            (dolist (entry category-entries)
              (insert (format "%-22s %-14s %s\n"
                              (plist-get entry :display)
                              (plist-get entry :source)
                              (plist-get entry :description)))
              (insert (format "  挿入内容: %s\n" (plist-get entry :inserts))))
            (insert "\n")))
        (my/racket-insert-exercise-hints-section)
        (goto-char (point-min))
        (special-mode)))
    buffer))

(defun my/racket-study-show-templates ()
  "Show a categorized help buffer for Racket study templates."
  (interactive)
  (pop-to-buffer (my/racket-study-templates-buffer)))

(defun my/racket-format-buffer ()
  "Indent the current Racket buffer."
  (interactive)
  (when (derived-mode-p 'racket-mode)
    (save-mark-and-excursion
      (save-restriction
        (widen)
        (let ((inhibit-message t))
          (indent-region (point-min) (point-max)))))))

(defun my/racket-format-buffer-before-save ()
  "Indent Racket buffers before saving when enabled."
  (when (and my/racket-format-on-save
             (derived-mode-p 'racket-mode)
             (not buffer-read-only))
    (my/racket-format-buffer)))

(defun my/racket-toggle-format-on-save ()
  "Toggle automatic Racket indentation before save in this buffer."
  (interactive)
  (setq-local my/racket-format-on-save (not my/racket-format-on-save))
  (message "Racket format on save: %s"
           (if my/racket-format-on-save "on" "off")))

(defun my/racket-company-setup ()
  "Prefer Racket-aware completion candidates."
  (when (boundp 'company-backends)
    (setq-local company-backends
                (append (when (fboundp 'company-racket-study)
                          '(company-racket-study))
                        '(company-capf
                          company-files
                          company-dabbrev-code
                          company-keywords
                          company-dabbrev))))
  (when (fboundp 'company-mode)
    (company-mode 1)))

(defun my/racket-insert-lang-line ()
  "Insert a starter language line for new empty .rkt files."
  (when (and buffer-file-name
             (string-match-p "\\.rkt\\'" buffer-file-name)
             (not (file-exists-p buffer-file-name))
             (= (buffer-size) 0))
    (insert "#lang racket\n\n")))

(defun my/racket-mode-setup ()
  "Enable a small Racket learning setup."
  (my/racket-insert-lang-line)
  (racket-xp-mode 1)
  (racket-input-mode 1)
  (my/racket-tempo-setup)
  (add-hook 'before-save-hook #'my/racket-format-buffer-before-save nil t)
  (my/racket-company-setup))

(use-package racket-mode
  :mode "\\.rkt\\'"
  :custom
  (racket-program "racket.exe")
  (racket-xp-eldoc-level 'summary)
  (racket-error-context 'medium)
  :bind
  (:map racket-mode-map
        ("C-c r r" . racket-run)
        ("C-c r R" . racket-run-and-switch-to-repl)
        ("C-c r t" . racket-test)
        ("C-c r e" . racket-send-definition)
        ("C-c r x" . racket-send-last-sexp)
        ("C-c r d" . racket-xp-describe)
        ("C-c r h" . racket-documentation-search)
        ("C-c r n" . racket-xp-next-error)
        ("C-c r p" . racket-xp-previous-error)
        ("C-c r ?" . my/racket-study-show-templates)
        ("C-c r f" . my/racket-toggle-format-on-save)
        ("C-c s" . tempo-complete-tag))
  :config
  (require 'racket-input)
  (require 'racket-repl)
  (require 'racket-xp)

  (add-hook 'racket-mode-hook #'my/racket-mode-setup)
  (add-hook 'racket-repl-mode-hook #'my/racket-company-setup))

(with-eval-after-load 'racket-repl
  (add-hook 'racket-repl-mode-hook #'my/racket-company-setup))

;; Start from home directory
(setq inhibit-startup-screen t)
(cd "~")

;; Default font
(cond
 ((eq system-type 'darwin)
  (set-face-attribute 'default nil
                      :family "PlemolJP Console NF"
                      :foundry "outline"
                      :slant 'normal
                      :weight 'regular
                      :height 220
                      :width 'normal))
 ((eq system-type 'windows-nt)
  (set-face-attribute 'default nil
                      :family "Consolas" ; customize here
                      :foundry "outline"
                      :slant 'normal
                      :weight 'regular
                      :height 130        ; customize here
                      :width 'normal)))

(message "ALL DONE.")
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(package-selected-packages nil))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(page-break-lines ((t (:foreground "gray30" :family "Courier" :height 1)))))


(provide 'init)
;;; init.el ends here
