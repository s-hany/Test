;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260410.2044"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "8635304365b6f9b2099ca28036798ac510225d36"
  :revdesc "8635304365b6"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
